import socket
import threading
import json
import os
import uuid  # Añadido para generar IDs únicos en el POST

HOST = '127.0.0.1'
PORT = 8080
JSON_FILE = 'database.json'

#Manejamos la concurrencia con mutex
file_lock = threading.Lock()

if not os.path.exists(JSON_FILE):
    with open(JSON_FILE, 'w') as f:
        json.dump({"recursos": {}}, f, indent=4)

def leer_json():
    with file_lock:
        with open(JSON_FILE, 'r') as f:
            return json.load(f)

def escribir_json(data):
    with file_lock:
        with open(JSON_FILE, 'w') as f:
            json.dump(data, f, indent=4)

def handle_client(client_socket, client_address):
    print(f"Conexión desde {client_address}")
    try:
        request_data = client_socket.recv(4096).decode('utf-8')
        if not request_data:
            return
        # Todo lo que está arriba de esa línea son las cabeceras (metadatos)
        # Todo lo que está abajo es el JSON que se envía en un POST o PUT.
        #Busca esa línea en blanco y corta el texto en dos partes. El 1 solo corta la primera vez que encuentra esa doble línea.
        parts = request_data.split('\r\n\r\n', 1) 
        headers_part = parts[0]
        #si es un GET, no hay cuerpo, simplemente asigna un texto vacío.
        body_part = parts[1] if len(parts) > 1 else "" 

        #Esto nos da una lista donde cada elemento es una cabecera.
        lines = headers_part.split('\r\n')
        #Obtenemos la instruccion principal y separamos la partes de la request line
        request_line = lines[0]
        request_line_parts = request_line.split(' ')

        if len(request_line_parts) < 3:
            enviar_respuesta_error(client_socket, "400 Bad Request", "Petición malformada.")
            return
        
        # Extrae la primera línea (GET /recursos/123 HTTP/1.1) para saber qué acción ejecutar y sobre qué objetivo.
        method, path, _ = request_line_parts
        recurso_id = path.split('/')[-1] if path != "/" and path != "/recursos" else None

        # ================= GET (Leer) =================
        if method == "GET":
            data = leer_json()
            if not recurso_id:
                #Busca el catalogo de elementos completo (No especifica ID)
                response_body = json.dumps(data) 
                enviar_respuesta(client_socket, "200 OK", "application/json", response_body)
            else:
                #Busca un elemento en especifico
                if recurso_id in data["recursos"]:
                    response_body = json.dumps({recurso_id: data["recursos"][recurso_id]})
                    enviar_respuesta(client_socket, "200 OK", "application/json", response_body)
                else:
                    #No existe el recurso
                    enviar_respuesta_error(client_socket, "404 Not Found", f"Recurso '{recurso_id}' no encontrado.")

        # ================= POST (Crear con ID automático) =================
        elif method == "POST":
            #Envia la petición a la raíz de esa colección recursos
            if path != "/recursos":
                #Si el cliente intenta hacer un POST a una URL específica
                enviar_respuesta_error(client_socket, "400 Bad Request", "Los POST deben enviarse a /recursos")
                return

            try:
                #Toma la cadena de texto plano que viene en el cuerpo de la petición y la transforma en un diccionario de Python real.
                nuevo_contenido = json.loads(body_part) if body_part else {} #Si el cuerpo viene vacío, asigna un diccionario vacío.
                nuevo_id = str(uuid.uuid4())[:8] # Genera un ID alfanumérico corto
                
                data = leer_json()
                data["recursos"][nuevo_id] = nuevo_contenido
                escribir_json(data)

                response_body = json.dumps({
                    "status": "success", 
                    "message": "Recurso creado exitosamente",
                    "id_generado": nuevo_id
                })
                # El código correcto para creación exitosa es 201 Created
                enviar_respuesta(client_socket, "201 Created", "application/json", response_body)
                
            except json.JSONDecodeError:
                enviar_respuesta_error(client_socket, "400 Bad Request", "JSON inválido en el cuerpo.")

        # ================= PUT (Actualizar/Crear con ID específico) =================
        elif method == "PUT":
            if not recurso_id:
                #No se encontró un recurso con esa ID
                enviar_respuesta_error(client_socket, "400 Bad Request", "Falta ID en la URL para el PUT.")
                return

            try:
                #Toma la cadena de texto plano que viene en el cuerpo de la petición y la transforma en un diccionario de Python real.
                nuevo_contenido = json.loads(body_part) if body_part else {} #Si el cuerpo viene vacío, asigna un diccionario vacío.
                data = leer_json()
                data["recursos"][recurso_id] = nuevo_contenido
                escribir_json(data)

                response_body = json.dumps({"status": "success", "message": f"Recurso '{recurso_id}' guardado."})
                enviar_respuesta(client_socket, "200 OK", "application/json", response_body)
                
            except json.JSONDecodeError:
                enviar_respuesta_error(client_socket, "400 Bad Request", "JSON inválido en el cuerpo.")
        # ================= PATCH (Modificación parcial) =================

        elif method == "PATCH":
            if not recurso_id:
                #No hay especificado una ID
                enviar_respuesta_error(client_socket, "400 Bad Request", "Falta ID en la URL para el PATCH.")
                return

            try:
                #Se toma el cuerpo de la petición con los cambios que mandó el cliente
                campos_a_modificar = json.loads(body_part) if body_part else {}
                data = leer_json()
                
                #Verifica primero si el ID realmente existe antes de modificar.
                if recurso_id in data["recursos"]:
                    # .update() modifica solo las llaves que le mandes, manteniendo las demás intactas
                    data["recursos"][recurso_id].update(campos_a_modificar)
                    escribir_json(data)

                    response_body = json.dumps({"status": "success", "message": f"Recurso '{recurso_id}' modificado parcialmente."})
                    enviar_respuesta(client_socket, "200 OK", "application/json", response_body)
                else:
                    enviar_respuesta_error(client_socket, "404 Not Found", f"No se puede modificar. '{recurso_id}' no existe.")
                    
            except json.JSONDecodeError:
                enviar_respuesta_error(client_socket, "400 Bad Request", "JSON inválido en el cuerpo.")

        # ================= DELETE (Borrar) =================
        elif method == "DELETE":
            if not recurso_id:
                #No hay especificado una ID
                enviar_respuesta_error(client_socket, "400 Bad Request", "Falta ID en la URL para eliminar.")
                return

            data = leer_json()
            if recurso_id in data["recursos"]:
                #Literalmente elimina el recurso XD
                del data["recursos"][recurso_id]
                escribir_json(data)
                
                response_body = json.dumps({"status": "success", "message": f"Recurso '{recurso_id}' eliminado."})
                enviar_respuesta(client_socket, "200 OK", "application/json", response_body)
            else:
                enviar_respuesta_error(client_socket, "404 Not Found", f"No se puede eliminar. '{recurso_id}' no existe.")

        else:
            enviar_respuesta_error(client_socket, "501 Not Implemented", f"Método '{method}' no soportado.")

    except Exception as e:
        enviar_respuesta_error(client_socket, "500 Internal Server Error", str(e))
    finally:
        client_socket.close()

def enviar_respuesta(client_socket, status, content_type, body):
    body_bytes = body.encode('utf-8')
    response_headers = (
        f"HTTP/1.1 {status}\r\n"
        f"Content-Type: {content_type}; charset=utf-8\r\n"
        f"Content-Length: {len(body_bytes)}\r\n"
        "Connection: close\r\n\r\n"
    )
    client_socket.sendall(response_headers.encode('utf-8') + body_bytes)

def enviar_respuesta_error(client_socket, status, mensaje):
    body = json.dumps({"error": status, "descripcion": mensaje})
    enviar_respuesta(client_socket, status, "application/json", body)

def iniciar_servidor():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_socket.bind((HOST, PORT))
    server_socket.listen(10)
    # Configuramos un timeout de 1 segundo para que no se bloquee infinitamente
    server_socket.settimeout(1.0)
    print(f"Servidor multi-hilo escuchando en http://{HOST}:{PORT}")
    print("Presiona Ctrl+C para apagar el servidor de forma segura.\n")
    try:
        while True:
            try:
                #Dejamos pasar a un cliente
                client_socket, client_address = server_socket.accept()
                #Creamos hilo para el cliente 
                threading.Thread(target=handle_client, args=(client_socket, client_address), daemon=True).start()
            except socket.timeout:
                continue
    finally:
        #Asegura que el puerto se libere si o si
        server_socket.close()

if __name__ == "__main__":
    try:
        iniciar_servidor()
    except KeyboardInterrupt:
        print("\nDetectado Ctrl+C. Apagando el servidor de forma segura...")
        print("Puerto liberado con éxito.")