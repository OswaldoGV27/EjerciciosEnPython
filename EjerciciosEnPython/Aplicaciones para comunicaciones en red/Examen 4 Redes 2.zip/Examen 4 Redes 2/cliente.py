import socket
import json
import re

HOST = '127.0.0.1'
PORT = 8080

def realizar_intercambio_http(string_peticion):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect((HOST, PORT))
    sock.sendall(string_peticion.encode('utf-8'))
    
    respuesta = ""
    while True:
        chunk = sock.recv(4096).decode('utf-8')
        if not chunk:
            break
        respuesta += chunk
        
    sock.close()
    return respuesta

if __name__ == "__main__":
    # --- 1. POST: Crear un recurso nuevo ---
    print("\n=== 1. POST (CREAR NUEVO RECURSO) ===")
    payload_post = {"nombre": "Sensor de temperatura", "ubicacion": "Laboratorio 3"}
    json_post = json.dumps(payload_post)
    
    peticion_post = (
        "POST /recursos HTTP/1.1\r\n"
        f"Host: {HOST}:{PORT}\r\n"
        "Content-Type: application/json\r\n"
        f"Content-Length: {len(json_post)}\r\n"
        "Connection: close\r\n\r\n"
        f"{json_post}"
    )
    print(realizar_intercambio_http(peticion_post))

    # --- 2. PUT: Crear o actualizar un recurso con ID específico ---
    print("\n=== 2. PUT (ACTUALIZAR NODO ESPECÍFICO) ===")
    payload_put = {"nombre": "Servidor Base", "estado": "Mantenimiento"}
    json_put = json.dumps(payload_put)
    
    peticion_put = (
        "PUT /recursos/nodo_test HTTP/1.1\r\n"
        f"Host: {HOST}:{PORT}\r\n"
        "Content-Type: application/json\r\n"
        f"Content-Length: {len(json_put)}\r\n"
        "Connection: close\r\n\r\n"
        f"{json_put}"
    )
    print(realizar_intercambio_http(peticion_put))

    # --- 3. PATCH: Modificar parcialmente el recurso ---
    
    print("\n=== 3. PATCH (MODIFICAR PARCIALMENTE) ===")
    payload_patch = {"estado": "Operativo"}  # Solo enviamos el campo que cambia
    json_patch = json.dumps(payload_patch)
    
    peticion_patch = (
        "PATCH /recursos/nodo_test HTTP/1.1\r\n"
        f"Host: {HOST}:{PORT}\r\n"
        "Content-Type: application/json\r\n"
        f"Content-Length: {len(json_patch)}\r\n"
        "Connection: close\r\n\r\n"
        f"{json_patch}"
    )
    print(realizar_intercambio_http(peticion_patch))
    
    # --- 4. GET: Leer todos los recursos para verificar ---
    print("\n=== 3. GET (VERIFICAR BASE DE DATOS) ===")
    peticion_get = (
        "GET /recursos HTTP/1.1\r\n"
        f"Host: {HOST}:{PORT}\r\n"
        "Connection: close\r\n\r\n"
    )
    print(realizar_intercambio_http(peticion_get))

    # --- 5. DELETE: Eliminar el recurso creado con PUT ---
    print("\n=== 4. DELETE (ELIMINAR RECURSO) ===")
    #peticion_delete = (
    #    "DELETE /recursos/nodo_test HTTP/1.1\r\n"
    #    f"Host: {HOST}:{PORT}\r\n"
    #   "Connection: close\r\n\r\n"
    #)
    #print(realizar_intercambio_http(peticion_delete))
    
    # --- 6. GET FINAL: Verificar que se eliminó ---
    print("\n=== 5. GET FINAL (VERIFICAR ELIMINACIÓN) ===")
    print(realizar_intercambio_http(peticion_get))